
import './App.css';
import Header from './components/Header/Header';
import { BrowserRouter, Route, Routes} from 'react-router-dom'
import LandingPage from './Screens/LandingPage/LandingPage';
import AddRecipe from './Screens/AddRecipe/AddRecipe';


const App = () => (
  <BrowserRouter>
  <Header />
  <main>
    
    <LandingPage />
   
  </main>
  
  </BrowserRouter>

);

export default App;
