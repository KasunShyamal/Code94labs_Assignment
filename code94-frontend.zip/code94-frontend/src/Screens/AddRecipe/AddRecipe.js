import React from 'react'

const AddRecipe = () => {
    return (
        <div>
            add
        </div>
    )
}

export default AddRecipe;
