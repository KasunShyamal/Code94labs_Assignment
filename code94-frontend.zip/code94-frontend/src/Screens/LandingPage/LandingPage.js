import React from 'react'
import { Button } from 'react-bootstrap'

const LandingPage = () => {
    return (
        <div>
           <hr></hr>
           <div align = "center">
               <a href = '/add'>
           <Button bg = "primary" variant='secondary'>Add recipe</Button>
           </a>
           </div>
           <hr></hr>
           
        </div>
    )
}

export default LandingPage
